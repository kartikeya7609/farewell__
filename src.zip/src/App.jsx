import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import './index.css';
import Calendar from './src/components/Calendar';
import './src/styles/calendar.css';

const initialItems = [
  { id: 1, img: '/image/img1.jpg', title: 'Farewell', type: 'FLOWER', desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti temporibus quis eum consequuntur voluptate quae doloribus distinctio.' },
  { id: 2, img: '/image/img2.jpg', title: 'Farewell', type: 'NATURE', desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti temporibus quis eum consequuntur voluptate quae doloribus distinctio.' },
  { id: 3, img: '/image/img4.jpg', title: 'Farewell', type: 'PLANT', desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti temporibus quis eum consequuntur voluptate quae doloribus distinctio.' },
  { id: 4, img: '/image/img3.jpg', title: 'Farewell', type: 'NATURE', desc: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti temporibus quis eum consequuntur voluptate quae doloribus distinctio.' },
];

const wait = (ms) => new Promise(res => setTimeout(res, ms));

// -------------------------
// COMPONENT: Parallax Layer Section
// -------------------------
const ParallaxItem = ({ item, isFinal = false }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const yBg = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  return (
    <div ref={ref} className="parallax-section">
      {/* Background (slow) */}
      <motion.div
         className="parallax-bg"
         style={{ 
           backgroundImage: `url(${item.img || item})`,
           y: yBg
         }}
      />

      {/* Overlay */}
      <div className="parallax-overlay" />

      {/* Content (normal speed) */}
      <motion.div 
        className="parallax-content"
        initial={{ opacity: 0, y: 50, scale: isFinal ? 0.9 : 1 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: isFinal ? 1.2 : 0.8, ease: "easeOut" }}
        viewport={{ once: false, margin: "-100px" }}
      >
        {isFinal ? (
          <>
            <h1 className="parallax-text">Welcome to the Farewell</h1>
            <p className="parallax-subtext">The journey ends here, but the memories remain.</p>
          </>
        ) : (
          <>
            <h2 className="parallax-text" style={{ fontSize: '3.5rem' }}>{item.title}</h2>
            <p className="parallax-subtext" style={{ fontSize: '1.2rem', color: '#fff' }}>{item.type}</p>
          </>
        )}
      </motion.div>

      {/* Optional foreground accent layer (fast) */}
      <motion.div
        style={{
          position: "absolute",
          bottom: "-10%",
          left: 0,
          width: "100%",
          height: "20%",
          background: "linear-gradient(to top, rgba(20,255,114,0.1), transparent)",
          zIndex: 4,
          y: useTransform(scrollYProgress, [0, 1], ["0%", "-50%"])
        }}
      />
    </div>
  );
};

function App() {
  const [items, setItems] = useState(initialItems);
  const [animationClass, setAnimationClass] = useState('');
  
  // Cinematic Sequence Phase
  const [phase, setPhase] = useState("front");
  const [passcode, setPasscode] = useState("");
  const [isError, setIsError] = useState(false);

  const validPasscodes = [
    "FAREWELL2026",
    "MEMORIES-FOR-LIFE",
    "WITHDRAW-MEMORIES",
    "NITDGP-FAREWELL",
    "IEEE-BANK-VAULT",
    "STAY-CONNECTED"
  ];

  const startSequence = async () => {
    if (validPasscodes.includes(passcode.toUpperCase())) {
      setIsError(false);
      setPhase("loading");
      // 1. Initial Loader
      await wait(1500);
      setPhase("calendar"); // 2. Show calendar

      // 3. Trigger 10-15 animations
      await wait(1500);
      setPhase("animate");

      // 4 & 5. Date gets circled, scales to screen
      await wait(1250);
      setPhase("zoom");

      // 6. Loader again 
      await wait(1000);
      setPhase("loading2");
      
      // 7. Finally, enter the main slider
      await wait(1000);
      setPhase("slider");
    } else {
      setIsError(true);
      setTimeout(() => setIsError(false), 2000);
    }
  };

  useEffect(() => {
    // Manage body scroll based on phase
    if (phase === "parallax") {
      document.body.classList.remove('no-scroll');
    } else {
      document.body.classList.add('no-scroll');
    }
  }, [phase]);

  const moveSlider = (direction) => {
    if (animationClass) return;

    setItems((prevItems) => {
      const newItems = [...prevItems];
      if (direction === 'next') {
        const firstItem = newItems.shift();
        newItems.push(firstItem);
      } else {
        const lastItem = newItems.pop();
        newItems.unshift(lastItem);
      }
      return newItems;
    });

    setAnimationClass(direction);

    setTimeout(() => {
      setAnimationClass('');
    }, 500); 
  };


  // -------------------------
  // RENDER: Front Page (Bank Theme)
  // -------------------------
  if (phase === "front") {
    return (
      <div className="front-page">
        <div className="bank-card">
          <div className="bank-header">
            <h3>IEEE Bank</h3>
            <p>NITDGP Branch</p>
          </div>
          <div className="bank-form">
            <div className="bank-input">
              <label style={{ color: isError ? '#ff4b2b' : '#14ff72' }}>
                {isError ? 'Invalid Passcode' : 'Enter Passcode'}
              </label>
              <input 
                type="text" 
                placeholder="e.g. WITHDRAW-MEMORIES" 
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                autoComplete="off"
                spellCheck={false}
                style={{ 
                  borderColor: isError ? '#ff4b2b' : 'rgba(255,255,255,0.1)',
                  textTransform: 'uppercase',
                  letterSpacing: '2px'
                }}
              />
              <p style={{ fontSize: '0.6rem', color: '#666', marginTop: '10px', textAlign: 'center' }}>
                Hint: Check the vault codes (e.g. FAREWELL2026)
              </p>
            </div>
            <motion.button 
              className="withdraw-btn"
              animate={isError ? { x: [-10, 10, -10, 10, 0] } : {}}
              whileHover={{ scale: 1.05, backgroundColor: '#14ff72', color: '#000' }}
              whileTap={{ scale: 0.95 }}
              onClick={startSequence}
            >
              Withdraw memories
            </motion.button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------
  // RENDER: Loading Sequence
  // -------------------------
  if (phase === "loading" || phase === "loading2") {
    return (
      <div className="loader-container" style={{ opacity: 1, visibility: 'visible' }}>
        <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="loader-text"
        >
            Farewell
        </motion.div>
        <div className="loader-bar"></div>
      </div>
    );
  }

  // -------------------------
  // RENDER: Calendar Cinematic Action
  // -------------------------
  if (phase === "calendar" || phase === "animate" || phase === "zoom") {
    return (
      <motion.div 
        className="calendar-wrapper-motion"
        style={{ 
          width: '100vw', 
          height: '100vh', 
          overflow: 'hidden', 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center', 
          background: '#000', 
          position: 'relative' 
        }}
      >
        <motion.div
           animate={{ scale: 1 }}
           style={{ transformOrigin: "center center", zIndex: 10, width: '100%', height: '100%' }}
        >
          <Calendar phase={phase} />
        </motion.div>

        {/* Shock flash at the very moment of zoom */}
        <AnimatePresence>
          {phase === "zoom" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 0.3 }}
              style={{ position: 'absolute', inset: 0, background: '#fff', zIndex: 999999, pointerEvents: 'none' }}
            />
          )}
        </AnimatePresence>
      </motion.div>
    );
  }

  // -------------------------
  // RENDER: Final Image Slider
  // -------------------------
  if (phase === "slider") {
    return (
      <motion.div 
        className={`slider ${animationClass}`}
        initial={{ opacity: 0, filter: "blur(20px)" }}
        animate={{ opacity: 1, filter: "blur(0px)" }}
        transition={{ duration: 1.5, ease: "easeOut" }}
      >
        <div className="list">
          {items.map((item) => (
            <div key={item.id} className="item">
              <img src={item.img} alt={item.type} />
              <div className="content">
                <div className="title">{item.title}</div>
                <div className="type">{item.type}</div>
                <div className="description">{item.desc}</div>
                <div className="button">
                  <button onClick={() => setPhase("parallax")}>ENTER FAREWELL</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="thumbnail">
          {items.map((item) => (
              <div key={item.id} className="item">
                <img src={item.img} alt="" />
              </div>
          ))}
        </div>

        <div className="nextPrevArrows">
          <button className="prev" onClick={() => moveSlider('prev')}> {'<'} </button>
          <button className="next" onClick={() => moveSlider('next')}> {'>'} </button>
        </div>
      </motion.div>
    );
  }

  // -------------------------
  // RENDER: Dedicated Parallax Page Sequence
  // -------------------------
  if (phase === "parallax") {
    return (
      <div className="parallax-container">
        {/* Scroll through all the images in parallax first */}
        {initialItems.map((item) => (
          <ParallaxItem key={item.id} item={item} />
        ))}

        {/* 8. Parallax Welcome Page at the very end */}
        <ParallaxItem item={'/image/img1.jpg'} isFinal={true} />
      </div>
    );
  }
}

export default App;
